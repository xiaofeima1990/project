# geoBaidu 

This is an extension for using Baidu geo api from geopy. 