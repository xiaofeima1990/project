"""
Utils.
"""

__version__ = "0.20"

def get_version():
    return __version__